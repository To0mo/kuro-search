# Kuro — Cloudflare Workers デプロイキット（1ファイル版）

## 含まれているもの

```
kuro-worker-bundle/
├── worker.js        ← 1ファイルにバンドルされた Worker (4.1MB)
├── wrangler.toml    ← Cloudflare 設定
└── assets/          ← 静的アセット（Workers が直接配信）
    ├── _next/static/  ← Next.js の JS/CSS/フォント
    ├── logo.svg
    └── robots.txt
```

## デプロイ手順

### 1. Cloudflare CLI (`wrangler`) をインストール

```bash
# 既に入っていればスキップ
npm install -g wrangler
# または
bun add -g wrangler
```

### 2. Cloudflare にログイン（初回のみ）

```bash
wrangler login
```

ブラウザが開いて Cloudflare 認証を求められます。許可すると `wrangler` がトークンを保存します。

### 3. デプロイ

```bash
cd kuro-worker-bundle
wrangler deploy
```

成功すると：

```
Deployed kuro-search triggers
  https://kuro-search.<your-subdomain>.workers.dev
```

この URL で即座にアクセス可能。

## ローカルでテスト（Workers ランタイム）

```bash
cd kuro-worker-bundle
wrangler dev
```

`http://localhost:8787` で本番 Workers と同じ環境が起動します。

## 動作確認

```bash
WORKER_URL="https://kuro-search.<your-subdomain>.workers.dev"

# トップページ
curl $WORKER_URL/

# 検索（一般）
curl "$WORKER_URL/api/search?q=typescript&page=1"

# ページ送り（Bing は Workers からだと first パラメータを正しく処理する）
curl "$WORKER_URL/api/search?q=typescript&page=2"
curl "$WORKER_URL/api/search?q=typescript&page=3"

# 画像検索（Openverse）
curl "$WORKER_URL/api/search?q=cat&type=image"

# ニュース
curl "$WORKER_URL/api/search?q=typescript&type=news"

# サジェスト
curl "$WORKER_URL/api/suggest?q=typescript"

# ページプレビュー
curl "$WORKER_URL/api/preview?url=https://example.com"
```

## 設定を変える場合

### Worker 名を変更

`wrangler.toml` の `name = "kuro-search"` を好きな名前に変更。URL の `<your-subdomain>` 部分は Cloudflare アカウントに紐付くので、Worker 名を変えると `https://<new-name>.<your-subdomain>.workers.dev` になります。

### 独自ドメインを設定

デプロイ後、Cloudflare Dashboard → Workers & Pages → kuro-search → Settings → Domains & Routes から追加。

```toml
# または wrangler.toml に追記
[[routes]]
pattern = "kuro.example.com/*"
zone_name = "example.com"
custom_domain = true
```

### Workers KV でエッジ間キャッシュ共有（任意）

```bash
wrangler kv namespace create CACHE
# → id が返る
```

`wrangler.toml` に追記：

```toml
[[kv_namespaces]]
binding = "CACHE"
id = "<返されたid>"
```

`src/app/api/search/route.ts` 等の `cache` 変数（Map）を `env.CACHE` に切り替えると、世界中のエッジでキャッシュが共有されます。

## 制限事項

### Cloudflare Workers Free プラン

- 月100,000リクエスト
- 10ms CPU / リクエスト（検索はほぼ I/O 待ちなので大丈夫）
- 1MB Worker（gzip 後）— 現状 886KB なので OK

### 外部 API の制限

- **Bing**（一般/ニュース検索）: API キー不要、利用制限なし（HTML スクレイプ）
- **Openverse**（画像検索）: 20/min、200/day（匿名）
- **Google Suggest**: 制限なし
- **z-ai SDK**（preview / extract-images のフォールバック）: 既存の `.z-ai-config` が必要。Workers 上で動かない場合は `src/app/api/preview/route.ts` と `extract-images/route.ts` を `fetchPage` 単独に修正すれば動きます

### Workers 上で z-ai SDK が動かない場合

`z-ai-web-dev-sdk` は Node.js の `Buffer` 等を使います。Workers は `nodejs_compat` で大部分をカバーしますが、問題が出たら次のように `page_reader` を呼ばずに自前 fetch だけにする：

`src/app/api/preview/route.ts` と `extract-images/route.ts` の `ZAI.create()` + `zai.functions.invoke("page_reader", ...)` を削除 → `fetchPage()` 単独で動くようになります。

## トラブルシューティング

### `CPU limits are not supported for the Free plan`

`wrangler.toml` から `[limits] cpu_ms = ...` を削除（今回の `wrangler.toml` には含まれていません）。

### `Worker exceeded CPU time limit`

重い処理をしていないので通常出ません。出る場合は `Bing` の HTML 解析か `Openverse` の JSON が大きすぎる可能性。`num_per_page` を減らすか `Buffer.from` 等の重い Node API を避ける。

### Bing が結果を返さない

Cloudflare の Bot Fight Mode が有効だと弾かれます。Workers のセキュリティ設定で無効化するか、`src/lib/bing-search.ts` の `User-Agent` を調整。

### Openverse 429

200/day の匿名制限に引っかかっています。`https://api.openverse.org/v1/` で無料トークン登録（OAuth）すると制限が上がります。

## 構成の理由

### なぜ1ファイルにバンドルしたか

`@opennextjs/cloudflare` が生成する `.open-next/` は10数個のディレクトリと数十ファイルに分かれており、デプロイ時に `wrangler` がこれらを1つの `worker.js` にバンドルします。最初からバンドル済みの `worker.js` を配布することで、ユーザー側のプロジェクト構成を気にせず `wrangler deploy` 一発でデプロイできます。

### なぜ assets/ は別ディレクトリのままか

Cloudflare Workers の Static Assets 機能（`[assets]` バインディング）は、Worker とは独立して最寄りのエッジから静的ファイルを配信します。これを1ファイルにまとめることはできませんし、まとめると CDN の利点が消えます。40個のファイル（フォントやJSバンドル）は Workers ランタイムを経由せず直接配信されるので速いです。

## 元の Next.js プロジェクトを Vercel にデプロイしたい場合

この ZIP は Cloudflare Workers 専用です。Vercel / Netlify にデプロイしたい場合は元の Next.js プロジェクト（`/home/z/my-project/`）を使います：

```bash
cd /your/path/to/original-nextjs-project
bun install
bun run build
vercel deploy  # または netlify deploy
```
